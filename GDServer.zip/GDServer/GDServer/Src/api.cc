#include "api.h"

#include "APIEnvir.h"
#include "ACAPinc.h"					// also includes APIdefs.h
#include "APICommon.h"

namespace api {

int createLine(double x1, double y1, double x2, double y2) {

  //WriteReport_Alert("Line %lf %lf %lf %lf\n", x1, y1, x2, y2);
  const char hwText[] = {"Line"};
  int id;

  GSErrCode err = ACAPI_CallUndoableCommand(hwText,
                                            [&]() -> GSErrCode {
    API_ElementMemo memo;
    API_Element lineElement;

    BNZeroMemory(&memo, sizeof(API_ElementMemo));
    BNZeroMemory(&lineElement, sizeof(API_Element));

    lineElement.line.begC.x = x1;
    lineElement.line.begC.y = y1;
    lineElement.line.endC.x = x2;
    lineElement.line.endC.y = y2;

    lineElement.header.typeID = API_LineID;
    lineElement.header.layer = 1;
    lineElement.header.floorInd = 0;

    err = ACAPI_Element_Create(&lineElement, NULL);
    if (err != NoError) {
      ErrorBeep("ACAPI_Element_Create (line)", err);
      return err;
    }

    API_Guid api_guid = lineElement.header.guid;
    GS::Guid gs_guid = APIGuid2GSGuid(api_guid);
    id = gs_guid.GetHashValue();

    ACAPI_DisposeElemMemoHdls(&memo);

    return err;

  });
  if (err != NoError)
    ErrorBeep("Yikes (line)", err);

  //WriteReport_Alert("Id returned: %zu\n", id);
  return  id;
}

int Circle::createCircle(double x1, double y1, double r) {

  //std::chrono::duration<double> timee;
  //auto start = std::chrono::high_resolution_clock::now();

  //WriteReport_Alert("Circle %lf %lf %lf\n", x1, y1, r);
  const char hwText[] = {"Circle"};
  int id;

  GSErrCode err = ACAPI_CallUndoableCommand(hwText,
                                            [&]() -> GSErrCode {

    API_ElementMemo memo;
    API_Element		circleElement;

    BNZeroMemory(&memo, sizeof(API_ElementMemo));
    BNZeroMemory(&circleElement, sizeof(API_Element));

    circleElement.circle.origC.x = x1;
    circleElement.circle.origC.y = y1;
    circleElement.circle.r = r;

    circleElement.circle.ratio = 1.0;
    circleElement.header.typeID = API_CircleID;
    circleElement.header.layer = 1;
    circleElement.header.floorInd = 0;

    err = ACAPI_Element_Create(&circleElement, &memo);
    if (err != NoError) {
      ErrorBeep("ACAPI_Element_Create (circle)", err);
    }

    API_Guid api_guid = circleElement.header.guid;
    GS::Guid gs_guid = APIGuid2GSGuid(api_guid);
    id = gs_guid.GetHashValue();

    ACAPI_DisposeElemMemoHdls(&memo);

    return err;


  });
  if (err != NoError)
    ErrorBeep("Yikes (circle)", err);

  //auto finish = std::chrono::high_resolution_clock::now();
  //timee = finish - start;
  //PrintTime(timee);

  //WriteReport_Alert("Id returned: %zu\n", id);
  return id;
}

int createCircle(double x1, double y1, double r) {

  //std::chrono::duration<double> timee;
  //auto start = std::chrono::high_resolution_clock::now();

  //WriteReport_Alert("Circle %lf %lf %lf\n", x1, y1, r);
  const char hwText[] = {"Circle"};
  int id;

  GSErrCode err = ACAPI_CallUndoableCommand(hwText,
                                            [&]() -> GSErrCode {

    API_ElementMemo memo;
    API_Element		circleElement;

    BNZeroMemory(&memo, sizeof(API_ElementMemo));
    BNZeroMemory(&circleElement, sizeof(API_Element));

    circleElement.circle.origC.x = x1;
    circleElement.circle.origC.y = y1;
    circleElement.circle.r = r;

    circleElement.circle.ratio = 1.0;
    circleElement.header.typeID = API_CircleID;
    circleElement.header.layer = 1;
    circleElement.header.floorInd = 0;

    err = ACAPI_Element_Create(&circleElement, &memo);
    if (err != NoError) {
      ErrorBeep("ACAPI_Element_Create (circle)", err);
    }

    API_Guid api_guid = circleElement.header.guid;
    GS::Guid gs_guid = APIGuid2GSGuid(api_guid);
    id = gs_guid.GetHashValue();

    ACAPI_DisposeElemMemoHdls(&memo);

    return err;


  });
  if (err != NoError)
    ErrorBeep("Yikes (circle)", err);

  //auto finish = std::chrono::high_resolution_clock::now();
  //timee = finish - start;
  //PrintTime(timee);

  //WriteReport_Alert("Id returned: %zu\n", id);
  return id;
}

int createSpline(std::vector<double> x, std::vector<double> y, bool closed) {

  //if(closed) WriteReport_Alert("Spline closed");
  //else WriteReport_Alert("Spline");
  /*
  for (int i = 0; i < x.size(); i++) {
  WriteReport_Alert("%lfx - %lfy", x[i], y[i]);
  }
  */
  const char hwText[] = {"Spline"};
  int id;

  //auto start = std::chrono::high_resolution_clock::now();

  GSErrCode err = ACAPI_CallUndoableCommand(hwText,
                                            [&]() -> GSErrCode {
    API_ElementMemo memo;
    API_Element	element;

    BNZeroMemory(&memo, sizeof(API_ElementMemo));
    BNZeroMemory(&element, sizeof(API_Element));

    element.header.typeID = API_SplineID;
    element.header.layer = 1;

    err = ACAPI_Element_GetDefaults(&element, &memo);
    if (err != NoError) {
      ErrorBeep("ACAPI_Element_GetMemo", err);
      return err;
    }

    element.spline.autoSmooth = true;
    element.spline.closed = closed;

    memo.coords = reinterpret_cast<API_Coord**> (BMAllocateHandle((int)(x.size() * sizeof(API_Coord)), ALLOCATE_CLEAR, 0));
    if (memo.coords == NULL) {
      ErrorBeep("Not enough memory to create slab polygon data", APIERR_MEMFULL);
      ACAPI_WriteReport("Memory Problem", true);
      ACAPI_DisposeElemMemoHdls(&memo);
    }

    for (int i = 0; i < x.size(); i++) {
      (*memo.coords)[i].x = x[i];
      (*memo.coords)[i].y = y[i];
    }

    err = ACAPI_Element_Create(&element, &memo);
    if (err != NoError) {
      ErrorBeep("ACAPI_Element_Create (spline)", err);
    }

    API_Guid api_guid = element.header.guid;
    GS::Guid gs_guid = APIGuid2GSGuid(api_guid);
    id = gs_guid.GetHashValue();

    ACAPI_DisposeElemMemoHdls(&memo);

    return err;

  });
  if (err != NoError)
    ErrorBeep("Yikes (circle)", err);

  //WriteReport_Alert("Id returned: %zu\n", id);
  /*
  auto finish = std::chrono::high_resolution_clock::now();
  std::chrono::duration<double> time = finish - start;
  PrintTime(time);
  */

  return id;
}

} //namespace api