#include "no_dependencies.h"

#include "my_service.h"

void StartRpcService(unsigned short port) {
  rpi_service::MyService rpi_service;
  rpi_service.Run(port);
}