#ifndef MY_SERVICE_H_
#define MY_SERVICE_H_

#include "rpi_service.h"

#include "api.h"

double add(int a, double b) {
  return a + b;
}

namespace rpi_service {

class MyService : public RpiService {
public:
  MyService() {
    ADD_FUNCTION(api::createLine);
    ADD_FUNCTION(api::Circle::createCircle);
    ADD_FUNCTION(api::createSpline);
    ADD_FUNCTION(add);
  }
};

} // namespace rpc_service

#endif  // MY_SERVICE_H_