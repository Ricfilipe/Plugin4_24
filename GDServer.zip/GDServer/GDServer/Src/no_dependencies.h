#ifndef NO_DEPENDENCIES_H_
#define NO_DEPENDENCIES_H_

void StartRpcService(unsigned short port);

#endif  // NO_DEPENDENCIES_H_
