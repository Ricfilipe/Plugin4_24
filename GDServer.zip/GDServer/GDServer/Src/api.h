#ifndef API_H_
#define API_H_

#include <vector>
#include <chrono>

namespace api {

class Circle {
public:
  static int createCircle(double x1, double y1, double r);
};

int createLine(double x1, double y1, double x2, double y2);

int createCircle(double x1, double y1, double r);

int createSpline(std::vector<double> x, std::vector<double> y, bool closed);

} //namespace api

#endif  // API_H_
